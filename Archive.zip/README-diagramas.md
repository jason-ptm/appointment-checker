# Diagramas de Arquitectura - Appointment Checker Frontend

Este directorio contiene diagramas PlantUML que documentan la arquitectura y estructura del proyecto de frontend para el sistema de verificación de citas médicas.

## Archivos de Diagramas

### 1. `component-diagram.puml`
**Diagrama de Componentes Principal**
- Muestra todos los componentes principales de la aplicación
- Visualiza las relaciones entre componentes
- Organiza los componentes por paquetes funcionales
- Incluye dependencias externas (React Router, Material-UI, Axios)

**Componentes principales:**
- **Core Application**: App.tsx, main.tsx, RouteWrapper
- **State Management**: Context Provider, Reducer, Actions, Types
- **Authentication**: PrivateRoute, Login Page, Auth Service
- **Layout Components**: Sidebar, SidebarLayout, LogoutButton
- **Dashboard**: Dashboard Page, Dashboard Service
- **Appointments**: AppointmentList, CreateAppointmentModal, DoctorCalendar
- **Selection Components**: SpecialtySelect, DoctorSelect

### 2. `architecture-diagram.puml`
**Diagrama de Arquitectura en Capas**
- Muestra la arquitectura del sistema organizada en capas
- Presenta la separación de responsabilidades
- Incluye la infraestructura y herramientas de build

**Capas de la arquitectura:**
- **Presentation Layer**: Páginas, componentes UI, framework
- **Application Layer**: Gestión de estado, routing, lógica de negocio
- **Service Layer**: Servicios API, cliente HTTP
- **Data Layer**: Almacenamiento local, APIs externas
- **Infrastructure**: Herramientas de build, dependencias

### 3. `data-flow-diagram.puml`
**Diagrama de Flujo de Datos**
- Muestra cómo fluye la información en la aplicación
- Documenta los flujos principales de autenticación y gestión de citas
- Incluye interacciones con el backend y almacenamiento local

**Flujos documentados:**
- Autenticación (login/logout)
- Carga de datos del dashboard
- Gestión de citas médicas
- Visualización del calendario del doctor

## Cómo Usar los Diagramas

### Visualización Online
1. Copia el contenido de cualquier archivo `.puml`
2. Ve a [PlantUML Online Server](http://www.plantuml.com/plantuml/uml/)
3. Pega el código y visualiza el diagrama

### Visualización Local
Si tienes PlantUML instalado localmente:

```bash
# Instalar PlantUML (requiere Java)
# macOS
brew install plantuml

# Generar imagen PNG
plantuml component-diagram.puml
plantuml architecture-diagram.puml
plantuml data-flow-diagram.puml
```

### En VS Code
1. Instala la extensión "PlantUML" de jebbs
2. Abre cualquier archivo `.puml`
3. Usa `Ctrl+Shift+P` y selecciona "PlantUML: Preview Current Diagram"

## Tecnologías Representadas

### Frontend Framework
- **React 19** con TypeScript
- **React Router** para navegación
- **Material-UI** para componentes UI

### State Management
- **Context API** con useReducer
- **Local Storage** para persistencia

### HTTP Client
- **Axios** para llamadas a API

### Build Tools
- **Vite** como bundler
- **TypeScript** para tipado estático
- **ESLint** para linting

## Estructura del Proyecto

```
src/
├── components/          # Componentes reutilizables
├── pages/              # Páginas principales
├── services/           # Servicios de API
├── context/            # Gestión de estado global
├── routes/             # Configuración de rutas
├── utils/              # Utilidades y constantes
├── theme/              # Configuración de Material-UI
└── assets/             # Recursos estáticos
```

## Notas de Diseño

- **Arquitectura en capas**: Separación clara de responsabilidades
- **Componentes modulares**: Reutilización y mantenibilidad
- **Gestión de estado centralizada**: Context API para estado global
- **Autenticación basada en JWT**: Seguridad y persistencia
- **UI consistente**: Material-UI para experiencia uniforme

## Mantenimiento

Para mantener los diagramas actualizados:

1. Actualiza los diagramas cuando agregues nuevos componentes
2. Refleja cambios en la arquitectura de servicios
3. Documenta nuevos flujos de datos importantes
4. Mantén la consistencia en la nomenclatura

---

*Estos diagramas ayudan a entender la estructura del proyecto y facilitan la colaboración en el equipo de desarrollo.* 