export type Error = {
  error: {
    message: string;
  };
};
