export const USER_TYPE = {
  ADMIN: "ADMIN",
  USER: "USER",
  NEW_USER: "NEW-USER",
  DOCTOR: "DOCTOR",
};

export const JWT_TOKEN = "jwt_token";
export const USER_DATA = "user_data";
